# Valent Trust Demo — Build State

**Project:** `valent-trust-demo`
**Framing:** "Vanta for suppliers" — compliance trust layer for regulated physical supply chains, starting with MoCRA-scoped cosmetic CMOs.
**Lineage:** Clean-slate rebuild. Predecessor `valent-demo-light-v3` remains at peer directory as reference for portable patterns (PDF personas, handshake toasts, evidence overlay).

## Current Phase

Phase 0 — Documentation (COMPLETE as of 2026-04-20)

Phase 1 — Scaffold (next)

## Phase ledger

| # | Phase | Status | Artifact |
|---|---|---|---|
| 0 | Draft PRDs + specs | complete | `docs/*.md` (13 files) |
| 1 | Scaffold Vite + Tailwind + shell | next | `src/` + config |
| 2 | Core screens (Trust Grid, Supplier Detail, Audit Bundle) | pending | `src/components/` |
| 3 | Supporting screens (Ingest, Review Queue, search, toasts) | pending | `src/components/` |
| 4 | Polish (admin, roadmap, mode flag, footer, parse-check) | pending | — |
| 5 | Self-review as end-user persona | pending | `docs/50-verification-plan.md` |
| 6 | Iterate to investor-ready | pending | loop on 5 |

## Next action (for fresh agent resuming this build)

1. Read this file.
2. Read `docs/00-master-prd.md` for thesis + scope.
3. Read `docs/40-build-order.md` for phase dependency graph.
4. Consult open tasks via TaskList (IDs 82–88).
5. Run the first `pending` task whose dependencies are satisfied.

## Guardrails for every phase

- Hard-coded JSON data layer — no fetch, no backend, no state libs beyond React Context.
- Stack: React 18 + Vite 5 + Tailwind 3 + Lucide + Recharts. No TypeScript.
- End user is a procurement team member at a mid-market cosmetic CMO. Every UI choice should pass the "does a Sarah in compliance ops find this useful on a Tuesday afternoon" test.
- Simpler than `valent-demo-light-v3`. Less data density per screen. Fewer KPI tiles. Larger tap targets. Clearer CTAs. Plain English.
- Supplier is the primary entity across every screen.
- Continuous monitoring is in the chrome, not a view.
- Evidence bundle is the hero output artifact.
- Margin framing is explicitly absent from the core loop.
- Parse-check every edit with `@babel/parser` — the sandbox lacks the Vite rollup `linux-arm64-gnu` binary, so `npm run build` cannot run here.
- Checkpoint every session-end: update this file's "Next action" block with the exact resume command.

## Scheduling handoff

If a session runs out of context mid-phase:
- Update this file with the exact next task ID + brief context.
- Seed a scheduled task via `mcp__scheduled-tasks__create_scheduled_task` with the prompt: "Resume Valent Trust Demo build per `/sessions/dazzling-amazing-faraday/mnt/v0/valent-trust-demo/STATE.md`. Start by reading STATE.md, then the referenced PRDs, then claim the next pending task."
- The scheduled agent will run fresh, read state, and pick up.

## Session log

- 2026-04-20 · Phase 0 kickoff. Directory created. Task graph seeded (82–88).
- 2026-04-20 · Phase 0 complete. 11 specs written: master PRD, user journeys, design system, state contract, 6 screen PRDs (trust grid, supplier detail, audit bundle, ingest inbox, review queue, admin, roadmap), build order, verification plan. Waiting for user sign-off before phase 1.
