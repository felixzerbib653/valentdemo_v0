# Screen PRD — Ingest Inbox

## Purpose

Answers "where does the evidence come from?" Supports daily operators who want to see what's landed recently, and pitch reviewers who want to understand the upstream plumbing.

## User goal

Scan recent evidence arrivals, resolve any that failed to auto-link to a supplier, and (for first-run configuration) see which evidence sources are connected.

## Primary journey supported

No primary journey. Secondary support for J1 (Sarah occasionally checks "what just came in"). Also: pitch-reviewer curiosity about the ingestion pipeline.

## Layout

Two regions stacked.

### 1. Sources strip (top)

A horizontal row of four source cards, each ~220px wide. Each card:

- Icon (Mail, HardDrive/Box, ServerCog for SFTP, Upload for manual)
- Source label ("Email · compliance@acmecosmetics.com", "SharePoint · /Compliance/Suppliers", "SFTP · edi.acme.com", "Manual upload")
- Status dot + text ("Connected · last sync 3m ago" / "Connected · last sync 1d ago" / etc.)
- Count chip ("14 this week")
- Settings ghost link ("Configure")

All four are connected in the demo (hard-coded). Clicking "Configure" emits a toast: "Source configuration opened (simulated)."

This strip is the "Vanta for your inbox" moment — it visibly locates where the compliance evidence originates.

### 2. Recent arrivals (the hero)

A vertical list of ingested documents, most recent first. ~50 rows visible in the demo, scrollable.

Each row ~56px tall:

- File-type icon
- Doc title (`text-sm`, `font-medium`) — "Certificate of Analysis · LEC-SOY-70 · lot 2024-0814"
- Source tag — small pill showing origin ("from email" / "from SharePoint" / etc.)
- Linked supplier (clickable chip) — "IMCD · Peter Greven · FEI:1234567"
- Ingested timestamp — "2m ago"
- Extraction confidence chip — High / Medium / Low
- Right-aligned: a status — "Linked to pillar · §606 FEI" (if auto-routed) or "Needs review" (if ambiguous) or "Failed to parse" (if extraction broke)

Rows with `Needs review` or `Failed to parse` status are visually weighted — a light amber or red left-edge bar, respectively.

Row click: opens `<DocumentPreview>` modal in-page. From the preview the user can assign the document to a supplier and pillar if the auto-link failed.

Above the list: a filter strip — "All · 42 | Needs review · 3 | Failed · 1 | Linked · 38" with the active filter highlighted. Sarah can use this to triage.

## Data contract

Reads `documents.js`. The document shape:

```js
{
  id: string,
  title: string,
  supplierId: string | null,       // null if auto-link failed
  pillarKey: PillarKey | null,
  source: 'email' | 'sharepoint' | 'sftp' | 'manual',
  sourceDetail: string,            // "compliance@acmecosmetics.com"
  ingestedAt: ISO string,
  extractionConfidence: 'high' | 'medium' | 'low',
  linkStatus: 'linked' | 'needs-review' | 'failed',
  flags: string[],                 // extraction warnings
  persona: PersonaKey,             // scan-light, photocopy, handwritten, etc.
}
```

Note: the `persona` field is ported from v3's ingestion data and controls how the document renders in the preview modal (clean scan vs. photocopied vs. handwritten). This is reused, not rebuilt.

## Copy register

- Plain English. "Needs review" beats "unresolved extraction." "Failed to parse" is acceptable jargon for this screen since the user chooses to be here.
- Source tags are friendly: "from email" not "mail ingest".
- Timestamps relative for recent, absolute for older-than-a-week.

## Interactions with other screens

- Row → `<DocumentPreview>` modal (local, reused on Supplier Detail).
- Linked supplier chip → navigate to that supplier's detail page.
- "Needs review" row → DocumentPreview modal opens in a mode that shows a "Link to supplier" picker. Picking a supplier emits a toast and updates the row status to `Linked` (simulated).
- "Configure" on source card → toast no-op.

## Empty / edge states

- Zero recent arrivals: empty state — "No documents ingested in the last 7 days. Sources appear connected." with a "Upload manually" ghost CTA.
- All sources disconnected (not possible in demo, but designed): source cards render in a muted state with a red dot and a "Fix connection" CTA.

## What this screen does not do

- Does not let the user *edit* extracted data. Extraction corrections route through `<DocumentPreview>` modal.
- Does not display a live extraction pipeline animation (that was a v3 feature that read as demo-ware). Trust keeps it calm.
- Does not show historical ingestion analytics. That's Admin territory.

## Investor-readiness gates (for phase 5)

- A reviewer who clicks into Ingest Inbox for the first time understands in under 10 seconds that this is the upstream plumbing, not the main product surface.
- The source cards visibly explain "connected to your email / drive / SFTP."
- The `Needs review` + `Failed` filters get a reviewer to a non-trivial workflow in one click.

## Known design questions to revisit

- Is this screen worth keeping as a standalone, or should it collapse into an "Evidence tab" on Supplier Detail plus a portfolio-wide "Needs review" count on the Trust Grid? Decision deferred to phase 5. Current plan: keep as standalone, validate in self-review.
- Should the source strip be collapsible (hidden by default) since it's mostly set-and-forget? Probably yes — collapse once phase 2 is shipped.
