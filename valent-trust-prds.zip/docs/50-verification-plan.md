# Verification Plan

This doc defines how phase 5 (self-review) is run and how phase 6 (iterate) uses its output.

## Protocol

Phase 5 runs in three passes.

### Pass 1 — PRD-to-code conformance

For each of the six live screens, the reviewer reads the PRD, then the code, and checks:

- Every layout element specced in the PRD is present in the code.
- Every data field the PRD references is populated in data.
- Every interaction the PRD specifies fires correctly.
- Every copy register rule is upheld.

Output per screen: a conformance score (pass / partial / fail) plus a defect list.

### Pass 2 — End-user journey walkthrough

The reviewer adopts Sarah's persona (Compliance Ops). Runs each journey (J1–J5) cold, without consulting the PRDs. For each journey logs:

- Completed? yes / partially / no
- Clicks to completion
- Unknown-term count (words the reviewer had to guess at)
- Dead-affordance count (clickable things that don't do anything useful)
- "What does this mean?" hesitation count
- Friction notes

### Pass 3 — Pitch-reviewer walkthrough

The reviewer adopts the Jim / Alpine persona. Runs a 90-second walkthrough. Logs:

- Can they articulate the wedge after 90 seconds?
- Can they articulate the buyer after 90 seconds?
- Can they articulate the artifact after 90 seconds?
- Can they articulate the expansion surface without being told?

## Rounds

Review runs in rounds. Each round appends a dated section below. Round 1 is triggered at phase-5 kickoff.

The exit criterion is: Round N produces fewer than 3 friction points per screen AND all pass-1 conformance scores are `pass`.

## Findings log

### Round 1 — pending (kickoff at phase 5)

*To be populated at phase 5.*

Template per screen:

```
#### Screen: [name]
Pass 1 conformance: [pass | partial | fail]
Pass 1 defects:
- [defect 1]
- [defect 2]
Pass 2 journey (J[n]):
  completed: [yes|partial|no]
  clicks: [n]
  unknown terms: [n] ([list])
  dead affordances: [n]
  friction notes:
  - [note]
Pass 3 pitch signal:
  [free text]
```

## What counts as "investor-ready"

All four must be true:

1. Every screen passes Pass 1 conformance.
2. Sarah can complete J1, J2, J3 in her expected click budget (J1 ≤ 4 clicks to acting on the worst supplier; J2 ≤ 3 clicks to audit bundle download; J3 ≤ 2 clicks from toast to evidence).
3. Jim can articulate the wedge, buyer, artifact, and expansion in a 90-second walkthrough without being prompted.
4. No critical-path affordance is dead (every button, every row click, every toast CTA does what it says).

## Tools available for self-review

- Read the rendered components by reading the JSX source.
- Parse-check via `@babel/parser` to confirm no structural breakage.
- `extract-text` on any generated artifact.
- Subagent delegation — spawn a fresh `general-purpose` agent to run passes 2 or 3 with no prior context, since self-review by the same agent that built the thing is compromised.

## Scheduling rule for reviews

Phase 5 is always run by a fresh subagent with no coding history in this session. Phase 6 (iteration) is run by the main thread. This separation is load-bearing — self-reviews by the author are noise.
